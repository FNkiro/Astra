import React, { useState } from "react";
import { useCart } from "@/hooks/useCart";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";

const GOVERNORATES = [
  "Tunis","Ariana","Ben Arous","Manouba","Nabeul","Zaghouan","Bizerte",
  "Béja","Jendouba","Le Kef","Siliana","Sousse","Monastir","Mahdia",
  "Sfax","Kairouan","Kasserine","Sidi Bouzid","Gabès","Medenine",
  "Tataouine","Gafsa","Tozeur","Kébili"
];

const SHIPPING_FEE = 7;

export default function CheckoutPage() {
  const { cartItems, getCartTotal, clearCart } = useCart();
  const navigate = useNavigate();

  const [form, setForm] = useState({
    name: "",
    phone: "",
    governorate: "",
    city: "",
    postalCode: "",
    address: ""
  });

  const [errors, setErrors] = useState({});

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const validate = () => {
    const newErrors = {};

    Object.keys(form).forEach((key) => {
      if (!form[key]) newErrors[key] = "Required";
    });

    if (!cartItems.length) {
      newErrors.cart = "Cart is empty";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const finalTotal = getCartTotal() + SHIPPING_FEE;

  const sendToDiscord = async () => {
    const webhook =
      "YOUR_DISCORD_WEBHOOK_HERE";

    const itemsText = cartItems
      .map((i) => `🛍️ ${i.product.title} x${i.quantity}`)
      .join("\n");

    const payload = {
      content: "🚨 **NEW ASTRA ORDER** 🚨",
      embeds: [
        {
          title: "📦 Order Summary",
          color: 0x111111,
          fields: [
            { name: "👤 Name", value: form.name, inline: true },
            { name: "📞 Phone", value: form.phone, inline: true },

            { name: "📍 Governorate", value: form.governorate, inline: true },
            { name: "🏙️ City", value: form.city, inline: true },
            { name: "📮 Postal Code", value: form.postalCode, inline: true },

            { name: "🏠 Address", value: form.address, inline: false },

            { name: "🛒 Items", value: itemsText || "None", inline: false },

            { name: "💰 Subtotal", value: `${getCartTotal()} DT`, inline: true },
            { name: "🚚 Shipping", value: `${SHIPPING_FEE} DT`, inline: true },
            { name: "💵 Total", value: `${finalTotal} DT`, inline: true },

            { name: "💳 Payment", value: "Cash on Delivery 💵", inline: true }
          ]
        }
      ]
    };

    const res = await fetch(webhook, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });

    if (!res.ok) {
      const text = await res.text();
      console.error("Webhook error:", text);
      throw new Error("Discord webhook failed");
    }
  };

  const handleSubmit = async () => {
    if (!validate()) return;

    try {
      await sendToDiscord();
      clearCart();
      navigate("/success");
    } catch (err) {
      alert("Error sending order ❌");
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-4 bg-black relative overflow-hidden">

      {/* SPACE BACKGROUND */}
      <div className="absolute inset-0 bg-gradient-to-b from-black via-[#05060a] to-black" />

      <div className="relative z-10 w-full max-w-3xl bg-zinc-900/90 backdrop-blur-xl border border-zinc-800 rounded-2xl p-6 text-white">

        <h1 className="text-3xl font-bold tracking-[0.3em] uppercase mb-6">
          ASTRA Checkout
        </h1>

        {errors.cart && (
          <p className="text-red-400 mb-3">{errors.cart}</p>
        )}

        {/* FORM */}
        <div className="grid md:grid-cols-2 gap-4">

          <input name="name" placeholder="Full Name"
            onChange={handleChange}
            className="p-3 rounded bg-zinc-800 border border-zinc-700 text-white"
          />
          {errors.name && <p className="text-red-400 text-sm">{errors.name}</p>}

          <input name="phone" placeholder="Phone Number"
            onChange={handleChange}
            className="p-3 rounded bg-zinc-800 border border-zinc-700 text-white"
          />

          <select name="governorate" onChange={handleChange}
            className="p-3 rounded bg-zinc-800 border border-zinc-700 text-white">
            <option value="">Governorate</option>
            {GOVERNORATES.map(g => (
              <option key={g} value={g}>{g}</option>
            ))}
          </select>

          <input name="city" placeholder="City"
            onChange={handleChange}
            className="p-3 rounded bg-zinc-800 border border-zinc-700 text-white"
          />

          <input name="postalCode" placeholder="Postal Code"
            onChange={handleChange}
            className="p-3 rounded bg-zinc-800 border border-zinc-700 text-white"
          />
        </div>

        <textarea name="address" placeholder="Full Address"
          onChange={handleChange}
          className="w-full mt-4 p-3 rounded bg-zinc-800 border border-zinc-700 text-white"
        />

        {/* INFO BOX */}
        <div className="mt-4 p-4 rounded bg-zinc-800 border border-zinc-700">
          <p className="font-semibold">🚚 Cash on Delivery</p>
          <p className="text-zinc-400 text-sm">
            ✔ You will receive a confirmation call 📞 after order placement
          </p>
        </div>

        {/* BUTTON */}
        <Button
          onClick={handleSubmit}
          className="w-full mt-6 bg-white text-black hover:bg-gray-200 font-bold tracking-widest"
        >
          Confirm Order
        </Button>

      </div>
    </div>
  );
}