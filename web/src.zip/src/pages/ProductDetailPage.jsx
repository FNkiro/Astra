import React, { useState, useEffect, useMemo } from 'react';
import { Helmet } from 'react-helmet';
import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  ChevronLeft,
  Minus,
  Plus,
  ShoppingCart,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { useCart } from '@/hooks/useCart';
import { useToast } from '@/hooks/use-toast';
import { getProduct } from '@/api/EcommerceApi';

export default function ProductDetailPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { addToCart } = useCart();
  const { toast } = useToast();

  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const [selectedVariant, setSelectedVariant] = useState(null);
  const [quantity, setQuantity] = useState(1);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  useEffect(() => {
    const fetchProduct = async () => {
      try {
        const data = await getProduct(id);

        if (!data) {
          navigate('/shop');
          return;
        }

        setProduct(data);
        setSelectedVariant(data.variants?.[0] || null);
      } catch (err) {
        toast({
          title: 'Error',
          description: err.message,
          variant: 'destructive',
        });
      } finally {
        setLoading(false);
      }
    };

    fetchProduct();
  }, [id]);

  const images = useMemo(() => {
    if (!product) return [];
    if (product.images?.length) return product.images;
    if (product.image) return [{ url: product.image }];
    return [];
  }, [product]);

  // ✅ FIXED PRICE LOGIC
  const price =
    selectedVariant?.price_formatted ||
    selectedVariant?.sale_price_formatted ||
    null;

  const displayPrice = price || 'COMING SOON';

  const handleAddToCart = async () => {
    if (!product || !selectedVariant) return;

    await addToCart(product, selectedVariant, quantity, 9999);

    toast({
      title: 'Added to cart',
      description: product.title,
    });
  };

  if (loading) {
    return <Skeleton className="h-96 w-full" />;
  }

  if (!product) return null;

  return (
    <div className="astra-section">
      <div className="astra-container">

        {/* BACK */}
        <Button onClick={() => navigate('/shop')} variant="ghost">
          <ChevronLeft className="mr-2" />
          Back
        </Button>

        <div className="grid lg:grid-cols-2 gap-12 mt-6">

          {/* IMAGE */}
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
            <img
              src={images[currentImageIndex]?.url}
              className="w-full h-[500px] object-cover rounded-2xl"
            />
          </motion.div>

          {/* DETAILS */}
          <motion.div className="space-y-6">

            {/* ✅ FIXED TITLE (clean + responsive + one line desktop) */}
            <h1 className="text-3xl md:text-4xl font-semibold tracking-[0.25em] uppercase md:whitespace-nowrap md:overflow-hidden md:text-ellipsis">
              {product.title || 'UNTITLED'}
            </h1>

            {/* PRICE */}
            <div className="text-2xl font-light tracking-widest">
              {displayPrice}
            </div>

            {/* DESCRIPTION */}
            <div
              className="text-muted-foreground leading-relaxed"
              dangerouslySetInnerHTML={{ __html: product.description || '' }}
            />

            {/* VARIANTS */}
            {product.variants?.length > 1 && (
              <div className="flex gap-2 flex-wrap">
                {product.variants.map((v) => (
                  <Button
                    key={v.id}
                    variant={selectedVariant?.id === v.id ? 'default' : 'outline'}
                    onClick={() => setSelectedVariant(v)}
                  >
                    {v.title}
                  </Button>
                ))}
              </div>
            )}

            {/* QUANTITY */}
            <div className="flex items-center gap-4">
              <Button onClick={() => setQuantity(q => Math.max(1, q - 1))}>
                <Minus />
              </Button>

              <span className="text-lg">{quantity}</span>

              <Button onClick={() => setQuantity(q => q + 1)}>
                <Plus />
              </Button>
            </div>

            {/* ADD */}
            <Button className="w-full tracking-widest uppercase">
              <ShoppingCart className="mr-2" />
              Add to cart
            </Button>

          </motion.div>
        </div>
      </div>
    </div>
  );
}