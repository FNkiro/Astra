import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Heart, Target, Users } from 'lucide-react';

const AboutPage = () => {
  const values = [
    {
      icon: Heart,
      title: 'Built with intent',
      description:
        'Every ASTRA piece is designed with purpose — no noise, no excess, just clean identity and strong presence.',
    },
    {
      icon: Target,
      title: 'Drop culture mindset',
      description:
        'We don’t follow seasons. We release moments. Limited drops only — when it’s ready, not when it’s forced.',
    },
    {
      icon: Users,
      title: 'Community driven',
      description:
        'ASTRA is worn by a growing culture, not customers. Every drop belongs to the people who move with the brand.',
    },
  ];

  return (
    <>
      <Helmet>
        <title>About - ASTRA</title>
        <meta
          name="description"
          content="ASTRA streetwear. Limited drops, clean design, strong identity."
        />
      </Helmet>

      {/* HERO */}
      <section className="relative min-h-[60vh] flex items-center justify-center overflow-hidden bg-secondary text-secondary-foreground">
        <div className="astra-container text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="mb-6 tracking-[0.3em] uppercase">
              About ASTRA
            </h1>

            <p className="text-xl md:text-2xl text-secondary-foreground/80 max-w-3xl mx-auto leading-relaxed">
              A streetwear label built on silence, precision, and limited drops.
              No trends. No noise. Just identity.
            </p>
          </motion.div>
        </div>
      </section>

      {/* STORY */}
      <section className="astra-section bg-background">
        <div className="astra-container">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-20">

            {/* TEXT */}
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="order-2 lg:order-1"
            >
              <h2 className="mb-6 tracking-[0.2em] uppercase">
                The vision
              </h2>

              <div className="space-y-4 text-muted-foreground leading-relaxed">
                <p>
                  ASTRA started with a simple idea: streetwear doesn’t need to scream to be seen.
                  It just needs presence.
                </p>

                <p>
                  Every drop is built slowly, intentionally — designed to feel rare, not mass-produced.
                  We focus on silhouettes, emotion, and identity rather than trends.
                </p>

                <p>
                  We don’t chase fashion cycles. We create releases that feel like moments — once they’re gone, they’re gone.
                </p>
              </div>
            </motion.div>

            {/* IMAGE */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="order-1 lg:order-2"
            >
              <div className="relative h-96 rounded-2xl overflow-hidden shadow-2xl">
                <img
                  src="https://cdn.discordapp.com/attachments/1473650357275197440/1510507963197161512/lofovud.png?ex=6a1d11aa&is=6a1bc02a&hm=4898ef3387872ea66d2ac81c1fd3efed8908fb8470c7605078f3d285059efaf5"
                  alt="ASTRA inspiration"
                  className="w-full h-full object-cover"
                />
              </div>
            </motion.div>

          </div>

          {/* VALUES */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-center mb-12"
          >
            <h2 className="mb-4 tracking-[0.2em] uppercase">
              Core principles
            </h2>

            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Everything we build comes from these rules. We don’t break them.
            </p>
          </motion.div>

          {/* GRID */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {values.map((value, index) => (
              <motion.div
                key={value.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="text-center"
              >
                <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-primary/10 text-primary mb-6">
                  <value.icon className="h-8 w-8" />
                </div>

                <h3 className="mb-3 tracking-[0.15em] uppercase">
                  {value.title}
                </h3>

                <p className="text-muted-foreground leading-relaxed">
                  {value.description}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default AboutPage;