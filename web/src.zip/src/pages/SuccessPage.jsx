import React from "react";
import { Link } from "react-router-dom";

export default function SuccessPage() {
  return (
    <div className="min-h-screen flex items-center justify-center px-6">
      <div className="text-center max-w-xl w-full">
        <h1 className="text-4xl font-bold mb-4">
          Order Submitted Successfully
        </h1>

        <p className="mb-8 opacity-80">
          Thank you for your order. We have received your submission and will
          process it shortly.
        </p>

        <div className="flex justify-center">
          <Link
            to="/"
            className="px-6 py-3 border transition-all"
          >
            Return Home
          </Link>
        </div>
      </div>
    </div>
  );
}