import React, { useEffect, useMemo, useState } from "react";
import ProductsList from "@/components/ProductsList";
import { getProducts } from "@/api/EcommerceApi";

const ShopPage = () => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [sortBy, setSortBy] = useState("newest");

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const data = await getProducts();
        setProducts(Array.isArray(data) ? data : []);
      } catch (err) {
        console.error("Failed to load products:", err);
        setProducts([]);
      } finally {
        setLoading(false);
      }
    };

    fetchProducts();
  }, []);

  const sortedProducts = useMemo(() => {
    const items = [...products];

    if (!items.length) return [];

    switch (sortBy) {
      case "price-low":
        return items.sort(
          (a, b) => (a.price_in_cents ?? 0) - (b.price_in_cents ?? 0)
        );

      case "price-high":
        return items.sort(
          (a, b) => (b.price_in_cents ?? 0) - (a.price_in_cents ?? 0)
        );

      case "newest":
      default:
        return items;
    }
  }, [products, sortBy]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="opacity-70">Loading products...</p>
      </div>
    );
  }

  return (
    <div>
      <ProductsList products={sortedProducts} />
    </div>
  );
};

export default ShopPage;