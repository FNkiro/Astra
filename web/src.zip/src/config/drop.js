// src/config/drop.js

export const DROP_IS_LIVE = true;

// product price
export const PRODUCT_PRICE_CENTS = 4800;

// delivery fee
export const DELIVERY_FEE_CENTS = 700;