import { createContext, useContext, useEffect, useState } from "react";

const CartContext = createContext();

const DELIVERY_FEE = 700;

export const CartProvider = ({ children }) => {
  const [cartItems, setCartItems] = useState([]);

  // LOAD CART
  useEffect(() => {
    const saved = localStorage.getItem("astra_cart");
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        setCartItems(Array.isArray(parsed) ? parsed : []);
      } catch {
        setCartItems([]);
      }
    }
  }, []);

  // SAVE CART
  useEffect(() => {
    localStorage.setItem("astra_cart", JSON.stringify(cartItems));
  }, [cartItems]);

  // ADD TO CART
  const addToCart = (product, variant, quantity = 1) => {
    if (!product || !variant) return;

    setCartItems((prev) => {
      const safe = Array.isArray(prev) ? prev : [];

      const existing = safe.find(
        (i) => i?.variant?.id === variant.id
      );

      if (existing) {
        return safe.map((i) =>
          i?.variant?.id === variant.id
            ? { ...i, quantity: i.quantity + quantity }
            : i
        );
      }

      return [
        ...safe,
        {
          product: {
            title: product.title || product.name || "ASTRA ITEM",
            image: product.image || "",
          },
          variant: {
            ...variant,
            price_in_cents: Number(variant.price_in_cents) || 0,
          },
          quantity,
        },
      ];
    });
  };

  // REMOVE
  const removeFromCart = (id) => {
    setCartItems((prev) =>
      prev.filter((i) => i?.variant?.id !== id)
    );
  };

  // UPDATE QTY
  const updateQuantity = (id, qty) => {
    setCartItems((prev) =>
      prev.map((i) =>
        i?.variant?.id === id
          ? { ...i, quantity: qty }
          : i
      )
    );
  };

  // CLEAR
  const clearCart = () => setCartItems([]);

  // TOTAL (SAFE - NO NaN EVER)
  const getCartTotal = () => {
    return cartItems.reduce((total, item) => {
      const price = item?.variant?.price_in_cents;

      if (typeof price !== "number") return total;

      const qty = item?.quantity || 1;

      return total + price * qty;
    }, 0);
  };

  // FINAL TOTAL WITH DELIVERY (7 DT)
  const getFinalTotal = () => {
    const base = getCartTotal();
    return base + DELIVERY_FEE;
  };

  return (
    <CartContext.Provider
      value={{
        cartItems,
        addToCart,
        removeFromCart,
        updateQuantity,
        clearCart,
        getCartTotal,
        getFinalTotal,
        DELIVERY_FEE,
      }}
    >
      {children}
    </CartContext.Provider>
  );
};

export const useCart = () => useContext(CartContext);