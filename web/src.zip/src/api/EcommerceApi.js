const PRODUCT_IMAGE="https://cdn.discordapp.com/attachments/1473650357275197440/1510498967933292614/asss.png";
const products=[{
 id:"1",
 name:"ASTRA Tee",
 title:"ASTRA Tee",
 description:"Premium oversized ASTRA t-shirt",
 image:PRODUCT_IMAGE,
 images:[{url:PRODUCT_IMAGE}],
 variants:[{id:"default",name:"Default",price_in_cents:4800,price_formatted:"48 DT"}]
}];
export async function getProducts(){return products;}
export async function getProduct(id){return products.find(p=>p.id===id);}
export const formatCurrency=(c)=>`${(Number(c||0)/100).toFixed(2)} DT`;
export default {getProducts,getProduct,formatCurrency};
